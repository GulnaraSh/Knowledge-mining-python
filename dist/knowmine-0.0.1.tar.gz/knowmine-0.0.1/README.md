# Knowledge mining python package

The package allows to extract relevant sentences from scientific
texts based on the provided keywords and connection words. 

## Documentation

Online documentation can be found [here](https://gulnarash.github.io/Knowledge-mining-python/).
