# Knowledge mining python package

The package allows to extract relevant sentences from scientific
texts based on the provided keywords. 
