# Knowledge mining python package

The package allows to extract relevant sentences from scientific
texts based on the provided keywords and connection words. 

# Requirements
git

See [here](https://git-scm.com/downloads).
or for Anaconda [here](https://anaconda.org/anaconda/git).

## Documentation

Online documentation can be found [here](https://gulnarash.github.io/Knowledge-mining-python/).


