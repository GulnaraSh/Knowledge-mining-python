# Knowledge mining python package

The package allows to extract relevant sentences from scientific
texts based on the provided keywords and connection words. 

# Requirements
pke model (Boudin, 2016)
See [here](https://github.com/boudinfl/pke/).

spacy 2.2

language model: python -m spacy download en_core_web_lg 

## Documentation

Online documentation can be found [here](https://gulnarash.github.io/Knowledge-mining-python/).


